#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


#reading the csv file
covid = pd.read_csv(r"C:\Users\Sumana bushireddy\Downloads\covid19.csv")
covid


# In[4]:


#copied the original file into a new variable called new_set
new_set = pd.DataFrame(covid)
new_set


# In[13]:


#found total cases by adding all the elements and then appended the column to new_set
new_set['Total cases'] = new_set['ConfirmedIndianNational'] + new_set['ConfirmedForeignNational'] +new_set['Cured'] + new_set['Deaths']
total_cases = new_set['Total cases'].sum()
new_set


# In[16]:


#grouped the dataset by date
group_set = new_set.groupby(new_set['Date'],sort=False)
group_set.sum()


# In[29]:


#found the starting and last index of a particular date
index = new_set[new_set["Date"] == "04/03/20"]
index


# In[30]:


#microtask 3 done
#found the total cases on 04th
TCasesReq = new_set.loc[39:44, 'Total cases']

TCasesReq.sum()


# In[33]:


#importing matplot and numpy for graph
import matplotlib.pyplot as plt
import numpy as np


# In[38]:


#finding the data types of the columns
new_set.dtypes


# In[47]:


#converting date datatype into string
new_set['Date']=new_set['Date'].astype(str)


# In[48]:


new_set.dtypes


# In[58]:


#appended only date and total cases column into a different variable
data = pd.DataFrame(new_set)
data [['Date' ,'Total cases']]


# In[60]:


#adding date column to x variable
x = data['Date']
x


# In[61]:


#adding total cases column to y variable
y = data['Total cases']


# In[66]:



#plotting the graph
plt.figure(figsize=(20,10))
plt.plot(x,y)
plt.title('variation in total cases')
plt.xlabel("Date")
plt.ylabel('Total cases')
plt.show()


# In[77]:


#taking the starting and last index of values on 04/03/20
index = new_set[new_set["Date"] == "04/03/20"]
index


# In[80]:


#taking the starting and last index of values on 21/03/20
index = new_set[new_set["Date"] == "21/03/20"]
index


# In[82]:


#initializing starting index on 04 as first_index and last index on 21st as last_index
first_index = 39
last_index = 269
indexes = np.array(range(first_index,last_index+1))
indexes


# In[121]:


#calculating difference, rate and avg of all
avg=0
for i in range(first_index, last_index):
    difference = new_set.loc[(i+1),'Total cases'] - new_set.loc[i,'Total cases']
    rate = difference/new_set.loc[i,'Total cases']
    avg = avg+rate
    print(rate)
avg = avg/(last_index-first_index)
print(avg)
    
    


# In[132]:


#appending rate to new_set
new_set['Rate'] = np.NaN
for i in range(first_index, last_index):
    difference = new_set.loc[(i+1),'Total cases'] - new_set.loc[i,'Total cases']
    rate = difference/new_set.loc[i,'Total cases']
    avg = avg+rate
    new_set.loc[(i+1),'Rate']=rate
new_set


# In[133]:


new_set.loc[range(first_index,last_index)]


# In[125]:


#microtask 4 done
#avg rate we got is 1.73
#given p_o = 31
#t=26
p_t = 31*(2.718**(1.73*26))
p_t


# In[ ]:





# In[ ]:




